package sample;

import java.util.Map;
import java.util.TreeMap;

public class SpamTester {
    private Map<String, Float> probabilities;

    public SpamTester(){
        probabilities=new TreeMap<>();
    }
}
